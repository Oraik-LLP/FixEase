---
name: Technical Precision
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1b1b1e'
  surface-container: '#1f1f22'
  surface-container-high: '#2a2a2d'
  surface-container-highest: '#353438'
  on-surface: '#e4e1e6'
  on-surface-variant: '#bfc7d4'
  inverse-surface: '#e4e1e6'
  inverse-on-surface: '#303033'
  outline: '#89919e'
  outline-variant: '#3f4752'
  surface-tint: '#9dcaff'
  primary: '#9dcaff'
  on-primary: '#003257'
  primary-container: '#009dff'
  on-primary-container: '#003257'
  inverse-primary: '#0062a1'
  secondary: '#c8c5cb'
  on-secondary: '#303034'
  secondary-container: '#47464b'
  on-secondary-container: '#b6b4ba'
  tertiary: '#9dcaff'
  on-tertiary: '#003257'
  tertiary-container: '#009dff'
  on-tertiary-container: '#003257'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d0e4ff'
  primary-fixed-dim: '#9dcaff'
  on-primary-fixed: '#001d35'
  on-primary-fixed-variant: '#00497b'
  secondary-fixed: '#e4e1e7'
  secondary-fixed-dim: '#c8c5cb'
  on-secondary-fixed: '#1b1b1f'
  on-secondary-fixed-variant: '#47464b'
  tertiary-fixed: '#d0e4ff'
  tertiary-fixed-dim: '#9dcaff'
  on-tertiary-fixed: '#001d35'
  on-tertiary-fixed-variant: '#00497b'
  background: '#131316'
  on-background: '#e4e1e6'
  surface-variant: '#353438'
  surface-deep: '#0C0C0E'
  surface-elevated: '#17171B'
  success-emerald: '#10B981'
  warning-amber: '#F59E0B'
  critical-red: '#EF4444'
  border-cyan: rgba(0, 157, 255, 0.15)
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.1em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
---

## Brand & Style
The design system is engineered for the intersection of automotive expertise and artificial intelligence. The personality is **calm and technically capable**, functioning as a digital co-pilot that provides "instrument-like clarity." It targets a premium demographic that values directness and protective reliability.

The visual style is a **Modern-Automotive** aesthetic: a high-contrast dark theme that utilizes deep blacks and technical blues to evoke a midnight drive or a high-end garage diagnostic bay. It blends **Minimalism** (expansive whitespace and editorial pacing) with **Glassmorphism** and **Neomorphism** to create tactile, physical-feeling interfaces. Precision is reinforced through 1px borders, subtle edge lighting (cyan), and fine grid textures that mimic technical blueprints.

## Colors
The palette is rooted in a deep, multi-layered dark foundation to provide a sense of immersion and premium quality.

- **Primary Accent:** #009DFF is used sparingly for critical actions, interactive states, and "edge lighting" effects to represent the AI's diagnostic pulse.
- **Surface Strategy:** Use `#0C0C0E` for deep background layers, `#111114` for the standard page background, and `#17171B` for elevated cards or modules.
- **Diagnostic States:** Status indicators use restrained semantic colors. Emerald, Amber, and Red are desaturated slightly to fit the dark environment while maintaining immediate legibility for safety-critical information.
- **Edge Lighting:** A 1px border or internal shadow using a low-opacity cyan (`rgba(0, 157, 255, 0.15)`) should be applied to elevated elements to simulate a technical glow.

## Typography
The typographic hierarchy emphasizes **tight-tracked, confident headlines** using Plus Jakarta Sans to mirror automotive branding. Body copy uses Inter for its neutral, systematic clarity, essential for technical diagnostic data.

- **Editorial Impact:** Use `display-lg` for hero sections with significant negative space.
- **Tracking:** Headlines should have negative letter spacing (-2% to -4%) to create a dense, premium feel.
- **Captions:** Labels and technical data points should use `label-sm` with increased letter spacing and uppercase styling to mimic instrument cluster readouts.

## Layout & Spacing
The layout follows a **fluid grid** with an emphasis on **long-form storytelling**. Large vertical margins and generous padding between sections allow technical information to "breathe," preventing cognitive overload during diagnostics.

- **Rhythm:** Use an 8px base unit. 
- **Grid:** A 12-column grid is standard for desktop. For data-heavy diagnostic views, use a 4-column sub-grid within cards.
- **Negative Space:** Content blocks should be separated by large gaps (e.g., 120px - 160px on desktop) to maintain a premium, editorial feel.
- **Technical Overlays:** Use a subtle 32px x 32px grid texture overlay on background layers to reinforce the engineering theme.

## Elevation & Depth
Depth is achieved through **soft neumorphic layering** and **tonal stacking**. 

- **Surface Layers:** The background is the lowest level (`#0C0C0E`). Interactive cards sit on top (`#111114`), and active/focused elements use `#17171B`.
- **Shadows:** Avoid heavy black shadows. Instead, use "inner glows" and very soft, large-radius ambient shadows (e.g., `box-shadow: 0 20px 40px rgba(0,0,0,0.5)`).
- **Glass Effects:** Use backdrop blurs (20px+) on navigation bars and floating diagnostic modals to create a sense of light passing through high-quality materials.
- **The "Cyan Pulse":** Primary buttons and active states should feature a subtle outer glow of `#009DFF` at 10-15% opacity to indicate the AI is "live."

## Shapes
The shape language combines oversized radii with precise internal borders.

- **Outer Radius:** Large containers and cards should use **24px to 28px** corner radii to feel approachable and modern.
- **Inner Radius:** Nested elements (like buttons inside a card) should use **18px** to maintain a harmonious "squircle" aesthetic.
- **Borders:** All primary containers must feature a **1px solid border** using the `border-cyan` variable or a subtle `white/10%` to define the geometry against the dark background.

## Components
- **Buttons:** Primary buttons are pill-shaped with a solid `#009DFF` background or a ghost style with a 1px cyan border. Use high-contrast white text.
- **Diagnostic Chips:** Small, rounded-full indicators that use semantic colors (Emerald/Amber/Red) for text and border, with a 5% opacity background of the same color.
- **Input Fields:** Darker than the container background, featuring a bottom-only 1px border that glows Primary Cyan on focus.
- **Cards:** Utilize the `#111114` background with a subtle inner gradient (top-left to bottom-right) to simulate a physical, curved surface.
- **Gauges:** Circular diagnostic indicators should use thin stroke weights and "needle" pointers to maintain the automotive metaphor.
- **Lists:** Clean rows separated by 1px dividers (`white/5%`), with chevron icons for drill-down actions.